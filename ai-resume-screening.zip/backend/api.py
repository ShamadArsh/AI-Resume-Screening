# ============================================================
# backend/api.py — FastAPI Application
# ============================================================
# REST API for the AI Resume Screening Platform.
# Endpoints:
#   POST /parse_resume       — extract structured data from a resume
#   POST /match_resume       — match a parsed resume against a JD
#   POST /schedule_interview — schedule an interview for a candidate
#   GET  /candidate/{id}     — get candidate details
#   PUT  /candidate/{id}/override — recruiter overrides AI status
#   GET  /health             — health check
#   GET  /stats              — pipeline statistics
# ============================================================

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from ai.jd_matcher import match_resume_to_jd
from ai.resume_parser import GeminiError, parse_resume_with_ai
from ai.scoring import ApplicationStatus, apply_override, determine_status
from backend.config import settings
from database.airtable import CandidateRecord, get_repository
from parser import parse_resume_bytes, parse_resume_file
from scheduler.gmail import get_email_service
from scheduler.google_calendar import get_calendar_service
from utils.logger import logger
from utils.validators import ValidationError, validate_file_extension

# ------------------------------------------------------------------
# App setup
# ------------------------------------------------------------------
app = FastAPI(
    title="AI Resume Screening & Interview Scheduling API",
    description="AI-powered recruitment pipeline: parse, match, score, schedule.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    root_path="/api",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins.split(",") if settings.allowed_origins != "*" else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ------------------------------------------------------------------
# Pydantic models
# ------------------------------------------------------------------
class JDMatchRequest(BaseModel):
    candidate_data: dict = Field(..., description="Structured candidate data from /parse_resume")
    jd_text: str = Field(..., description="Job description text")


class ScheduleInterviewRequest(BaseModel):
    candidate_id: str = Field(..., description="Airtable/mock record ID")
    date: Optional[str] = Field(None, description="ISO datetime, e.g. 2025-07-10T09:00:00Z")
    interviewer_email: str = ""


class OverrideRequest(BaseModel):
    new_status: str = Field(..., description="Shortlisted | Manual Review | Rejected | Interview Scheduled")
    recruiter: str = ""
    note: str = ""


class CandidateResponse(BaseModel):
    id: str
    candidate_name: str = ""
    email: str = ""
    phone: str = ""
    experience: str = ""
    skills: list[str] = []
    match_score: int = 0
    matching_skills: list[str] = []
    missing_skills: list[str] = []
    ai_summary: str = ""
    recommendation: str = ""
    application_status: str = ""
    recruiter_notes: str = ""
    interview_status: str = ""
    interview_date: str = ""
    interview_link: str = ""
    created_time: str = ""
    updated_time: str = ""


# ------------------------------------------------------------------
# Exception handlers
# ------------------------------------------------------------------
@app.exception_handler(ValidationError)
async def validation_error_handler(request, exc: ValidationError):
    logger.event("validation_error", level=40, error=str(exc))
    return JSONResponse(status_code=400, content={"error": "validation_error", "detail": str(exc)})


@app.exception_handler(GeminiError)
async def gemini_error_handler(request, exc: GeminiError):
    logger.event("gemini_error", level=40, error=str(exc))
    return JSONResponse(status_code=503, content={"error": "ai_error", "detail": str(exc)})


# ------------------------------------------------------------------
# Pipeline orchestrator (used by both API and n8n webhook)
# ------------------------------------------------------------------
def run_full_pipeline(resume_text: str, jd_text: str) -> CandidateRecord:
    """
    Full pipeline: parse → match → score → store.
    Returns the stored CandidateRecord (with id).
    """
    logger.event("pipeline_start", resume_chars=len(resume_text), jd_chars=len(jd_text))

    # 1. AI extraction
    candidate_data = parse_resume_with_ai(resume_text)
    logger.event("pipeline_extracted", name=candidate_data.get("name"))

    # 2. JD matching
    match_result = match_resume_to_jd(candidate_data, jd_text)
    logger.event("pipeline_matched", score=match_result.get("match_score"))

    # 3. Business rules
    status = determine_status(match_result.get("match_score", 0))

    # 4. Store in Airtable (or mock)
    repo = get_repository()
    record = CandidateRecord(
        candidate_name=candidate_data.get("name", ""),
        email=candidate_data.get("email", ""),
        phone=candidate_data.get("phone", ""),
        experience=str(candidate_data.get("experience", "")),
        skills=candidate_data.get("skills", []),
        match_score=match_result.get("match_score", 0),
        matching_skills=match_result.get("matching_skills", []),
        missing_skills=match_result.get("missing_skills", []),
        ai_summary=match_result.get("ai_summary", ""),
        recommendation=match_result.get("hiring_recommendation", ""),
        application_status=status.value,
        resume_text=resume_text,
    )
    record_id = repo.create(record)
    record.id = record_id

    # 5. Send appropriate email
    email_svc = get_email_service()
    if record.email:
        if status == ApplicationStatus.SHORTLISTED:
            email_svc.send_shortlisted(record.email, record.candidate_name, record.match_score, record.ai_summary)
        elif status == ApplicationStatus.REJECTED:
            email_svc.send_rejected(record.email, record.candidate_name)
        else:
            email_svc.send_application_received(record.email, record.candidate_name)

    logger.event("pipeline_done", record_id=record_id, status=status.value)
    return record


# ------------------------------------------------------------------
# ENDPOINTS
# ------------------------------------------------------------------

@app.get("/health")
async def health():
    """Health check — returns service status and config flags."""
    return {
        "status": "healthy",
        "service": settings.app_name,
        "time": datetime.now(timezone.utc).isoformat(),
        "config": {
            "gemini_configured": bool(settings.gemini_api_key),
            "airtable_configured": bool(settings.airtable_api_key and settings.airtable_base_id),
            "redis_url": settings.redis_url.split("@")[-1] if "@" in settings.redis_url else settings.redis_url,
            "google_oauth_configured": bool(settings.google_client_id),
            "cache_enabled": settings.cache_enabled,
        },
    }


@app.post("/parse_resume")
async def parse_resume(file: UploadFile = File(...)):
    """
    Upload a resume (PDF/DOCX) and extract structured data via Gemini 2.5 Flash.
    Returns the structured candidate JSON.
    """
    logger.event("endpoint_call", endpoint="/parse_resume", filename=file.filename)

    # Validate file type
    try:
        validate_file_extension(file.filename or "")
    except ValidationError:
        raise HTTPException(status_code=400, detail=f"Unsupported file: {file.filename}")

    file_bytes = await file.read()
    try:
        resume_text = parse_resume_bytes(file.filename, file_bytes)
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.event("parse_error", level=40, error=str(exc))
        raise HTTPException(status_code=422, detail=f"Failed to parse file: {exc}")

    try:
        candidate_data = parse_resume_with_ai(resume_text)
    except GeminiError as exc:
        raise HTTPException(status_code=503, detail=f"AI parsing failed: {exc}")

    return {
        "status": "success",
        "filename": file.filename,
        "candidate": candidate_data,
    }


@app.post("/match_resume")
async def match_resume(
    file: UploadFile = File(..., description="Resume file (PDF/DOCX)"),
    jd_text: str = Form(..., description="Job description text"),
):
    """
    Upload a resume + JD text, parse + match + score + store the full pipeline.
    This is the primary endpoint used by the Streamlit dashboard and n8n.
    """
    logger.event("endpoint_call", endpoint="/match_resume", filename=file.filename)

    try:
        validate_file_extension(file.filename or "")
    except ValidationError:
        raise HTTPException(status_code=400, detail=f"Unsupported file: {file.filename}")

    file_bytes = await file.read()
    try:
        resume_text = parse_resume_bytes(file.filename, file_bytes)
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.event("parse_error", level=40, error=str(exc))
        raise HTTPException(status_code=422, detail=f"Failed to parse: {exc}")

    try:
        record = run_full_pipeline(resume_text, jd_text)
    except GeminiError as exc:
        raise HTTPException(status_code=503, detail=f"AI failed: {exc}")

    return {
        "status": "success",
        "candidate": record.to_dict(),
    }


@app.post("/schedule_interview")
async def schedule_interview(req: ScheduleInterviewRequest):
    """Schedule an interview via Google Calendar + send Gmail invitation."""
    logger.event("endpoint_call", endpoint="/schedule_interview", candidate_id=req.candidate_id)

    repo = get_repository()
    record = repo.get_by_id(req.candidate_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Candidate not found")

    # Parse requested date or auto-pick next slot
    from datetime import datetime as dt
    start_dt = None
    if req.date:
        try:
            start_dt = dt.fromisoformat(req.date.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use ISO 8601.")

    calendar_svc = get_calendar_service()
    event = calendar_svc.create_interview_event(
        candidate_name=record.candidate_name,
        candidate_email=record.email,
        start_time=start_dt,
        interviewer_email=req.interviewer_email,
    )

    # Update record
    repo.update(req.candidate_id, {
        "Application Status": ApplicationStatus.INTERVIEW_SCHEDULED.value,
        "Interview Status": "Scheduled",
        "Interview Date": event["start"],
        "Interview Link": event["meeting_link"],
    })

    # Send email
    email_svc = get_email_service()
    if record.email:
        date_str = start_dt.strftime("%B %d, %Y") if start_dt else "TBD"
        time_str = start_dt.strftime("%I:%M %p UTC") if start_dt else "TBD"
        email_svc.send_interview_invitation(
            record.email, record.candidate_name, date_str, time_str, event["meeting_link"]
        )

    logger.event("interview_scheduled_endpoint", candidate_id=req.candidate_id, event_id=event["event_id"])
    return {
        "status": "success",
        "event": event,
    }


@app.get("/candidate/{candidate_id}")
async def get_candidate(candidate_id: str):
    """Get full candidate details by record ID."""
    logger.event("endpoint_call", endpoint="/candidate", candidate_id=candidate_id)
    repo = get_repository()
    record = repo.get_by_id(candidate_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return record.to_dict()


@app.get("/candidates")
async def list_candidates():
    """List all candidates."""
    repo = get_repository()
    records = repo.list_all()
    return {"count": len(records), "candidates": [r.to_dict() for r in records]}


@app.put("/candidate/{candidate_id}/override")
async def override_status(candidate_id: str, req: OverrideRequest):
    """Recruiter overrides the AI-determined status."""
    logger.event("endpoint_call", endpoint="/override", candidate_id=candidate_id)

    repo = get_repository()
    record = repo.get_by_id(candidate_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Candidate not found")

    try:
        new_status = apply_override(
            record.application_status, req.new_status, req.recruiter, req.note
        )
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid status: {req.new_status}")

    repo.update(candidate_id, {
        "Application Status": new_status.value,
        "Recruiter Notes": (record.recruiter_notes + "\n" if record.recruiter_notes else "") + req.note,
    })

    return {"status": "success", "new_status": new_status.value}


@app.get("/stats")
async def stats():
    """Pipeline statistics."""
    repo = get_repository()
    records = repo.list_all()

    total = len(records)
    shortlisted = sum(1 for r in records if r.application_status == ApplicationStatus.SHORTLISTED.value)
    review = sum(1 for r in records if r.application_status == ApplicationStatus.MANUAL_REVIEW.value)
    rejected = sum(1 for r in records if r.application_status == ApplicationStatus.REJECTED.value)
    scheduled = sum(1 for r in records if r.application_status == ApplicationStatus.INTERVIEW_SCHEDULED.value)
    avg_score = sum(r.match_score for r in records) / total if total else 0

    return {
        "total_candidates": total,
        "shortlisted": shortlisted,
        "manual_review": review,
    "rejected": rejected,
        "interview_scheduled": scheduled,
        "average_match_score": round(avg_score, 1),
        "cache_backend": type(get_cache()).__name__,  # noqa: F821
    }


# ------------------------------------------------------------------
# n8n Webhook — full pipeline from a single POST
# ------------------------------------------------------------------
@app.post("/webhook/process_resume")
async def webhook_process_resume(
    file: UploadFile = File(...),
    jd_text: str = Form(...),
):
    """
    Webhook for n8n: receives resume + JD, runs full pipeline.
    Same as /match_resume but with webhook semantics (for n8n integration).
    """
    logger.event("webhook_call", endpoint="/webhook/process_resume", filename=file.filename)
    return await match_resume(file, jd_text)


# Import for /stats endpoint (avoids circular import at top)
from database.redis_cache import get_cache  # noqa: E402
