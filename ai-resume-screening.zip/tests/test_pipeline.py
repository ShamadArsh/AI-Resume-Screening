# ============================================================
# tests/test_pipeline.py — Integration tests for the full pipeline
# ============================================================

import pytest
from fastapi.testclient import TestClient

from backend.api import app, run_full_pipeline
from database.airtable import CandidateRecord, get_repository


@pytest.fixture
def client():
    return TestClient(app)


class TestPipelineStoreAndScore:
    """Test the store + score portion of the pipeline (no Gemini needed)."""

    def test_store_candidate_in_mock_repo(self):
        repo = get_repository()
        record = CandidateRecord(
            candidate_name="Test Candidate",
            email="test@example.com",
            match_score=85,
            application_status="Shortlisted",
            skills=["Python", "FastAPI"],
        )
        record_id = repo.create(record)
        assert record_id  # non-empty ID

        # Retrieve
        fetched = repo.get_by_id(record_id)
        assert fetched is not None
        assert fetched.candidate_name == "Test Candidate"
        assert fetched.match_score == 85

    def test_update_candidate_status(self):
        repo = get_repository()
        record = CandidateRecord(
            candidate_name="Override Test",
            email="override@test.com",
            match_score=50,
            application_status="Rejected",
        )
        record_id = repo.create(record)

        updated = repo.update(record_id, {
            "Application Status": "Shortlisted",
            "Recruiter Notes": "Great portfolio override",
        })
        assert updated is not None
        assert updated.application_status == "Shortlisted"

    def test_list_candidates(self):
        repo = get_repository()
        records = repo.list_all()
        assert isinstance(records, list)


class TestAPIWorkflowViaClient:
    """Test API workflow integration via TestClient."""

    def test_health_works(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200

    def test_full_candidate_lifecycle(self, client):
        """Create a candidate via repo, then fetch via API."""
        repo = get_repository()
        record = CandidateRecord(
            candidate_name="Lifecycle Test",
            email="lifecycle@test.com",
            phone="+1-555-000-1111",
            match_score=92,
            application_status="Shortlisted",
            skills=["Python", "Docker", "Kubernetes"],
            matching_skills=["Python", "Docker"],
            missing_skills=["Kubernetes"],
            ai_summary="Strong backend engineer with excellent Python skills.",
            recommendation="Strongly Recommended",
        )
        record_id = repo.create(record)

        # Fetch via API
        resp = client.get(f"/candidate/{record_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["candidate_name"] == "Lifecycle Test"
        assert data["match_score"] == 92

        # Override status via API
        resp = client.put(
            f"/candidate/{record_id}/override",
            json={"new_status": "Manual Review", "note": "Need second opinion"},
        )
        assert resp.status_code == 200
        assert resp.json()["new_status"] == "Manual Review"

    def test_stats_after_operations(self, client):
        resp = client.get("/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_candidates"] >= 0
