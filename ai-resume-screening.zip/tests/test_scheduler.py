# ============================================================
# tests/test_scheduler.py — Unit tests for scheduler mock mode
# ============================================================

import pytest
from scheduler.gmail import EmailService, EmailTemplates
from scheduler.google_calendar import CalendarService


class TestEmailServiceMock:
    """Test Gmail service in mock mode (no OAuth credentials)."""

    def test_mock_mode_when_no_creds(self):
        svc = EmailService()
        assert svc.is_mock is True

    def test_send_email_mock(self):
        svc = EmailService()
        result = svc.send_email(
            to="candidate@example.com",
            subject="Test Subject",
            body_text="Hello, this is a test.",
        )
        assert result["status"] == "mock_sent"
        assert result["mock"] is True
        assert "message_id" in result

    def test_send_application_received(self):
        svc = EmailService()
        result = svc.send_application_received("candidate@example.com", "Alice")
        assert result["status"] == "mock_sent"

    def test_send_shortlisted(self):
        svc = EmailService()
        result = svc.send_shortlisted("candidate@example.com", "Alice", 90, "Great fit")
        assert result["status"] == "mock_sent"

    def test_send_interview_invitation(self):
        svc = EmailService()
        result = svc.send_interview_invitation(
            "candidate@example.com", "Alice", "July 10", "2:00 PM", "https://meet.google.com/abc"
        )
        assert result["status"] == "mock_sent"

    def test_send_rejected(self):
        svc = EmailService()
        result = svc.send_rejected("candidate@example.com", "Alice")
        assert result["status"] == "mock_sent"


class TestEmailTemplates:
    def test_application_received_returns_tuple(self):
        text, html = EmailTemplates.application_received("Alice")
        assert "Alice" in text
        assert "Alice" in html
        assert "<html>" in html

    def test_interview_invitation_has_link(self):
        text, html = EmailTemplates.interview_invitation("Bob", "July 10", "2:00 PM", "https://meet.google.com/test")
        assert "https://meet.google.com/test" in html
        assert "Bob" in text

    def test_shortlisted_has_score(self):
        text, html = EmailTemplates.shortlisted("Carol", 85, "Excellent candidate")
        assert "85" in text
        assert "Carol" in text


class TestCalendarServiceMock:
    """Test Google Calendar service in mock mode."""

    def test_mock_mode_when_no_creds(self):
        svc = CalendarService()
        assert svc.is_mock is True

    def test_create_interview_event_mock(self):
        svc = CalendarService()
        result = svc.create_interview_event(
            candidate_name="Alice",
            candidate_email="alice@example.com",
        )
        assert result["mock"] is True
        assert "event_id" in result
        assert "meeting_link" in result
        assert "meet.google.com" in result["meeting_link"]
        assert "start" in result
        assert "end" in result

    def test_mock_event_has_valid_meeting_link(self):
        svc = CalendarService()
        result = svc.create_interview_event("Bob", "bob@test.com")
        assert result["meeting_link"].startswith("https://meet.google.com/")
